#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main(int argc, char *argv[])
{
	if(argc!=2)
	{
		printf("\nError in passing arguments..");
		return 0;

	}

	FILE *fp;
	char *file_ptr[20],buffer[100],cname[50];
	int choice,ch,size,flag=0,i=0,ch2,len,lno,j;

	strcpy(cname,"./svc ");
	strcat(cname,argv[1]);

	do
	{	printf("\n1. Appending in the file.\n2. Deletion of specific line in the file.\n3. Show the file\n4. Exit");
		printf("\nEnter your choice:");
		scanf("%d",&choice);

		switch(choice)
		{
		case 1:
				flag=0;
				fp=fopen(argv[1],"a+");
				fseek(fp,0,SEEK_END);
				size=ftell(fp);

				fseek(fp,0,SEEK_SET);
				if(size==0)
				{
					flag=1;
				}
				else
				{
					i=0;
					while(fgets(buffer,11,fp))
					{
						i++;
					}
				}
				if(flag)
				{
					printf("\nYou can add 20 lines more with 10 characters in each line");
					do
					{
						printf("\nEnter the line:\n");
						getchar();
						gets(buffer);

						len=strlen(buffer);
						if(len>10)
						{
							buffer[10]='\0';
						}
						fprintf(fp,"%s\n",buffer);
						i++;
						if(i==20)
						{
							printf("\nLimit reached..");
						}
						else
						{
							printf("\nDo you want to enter more lines...(Yes:1 No:0):");
							scanf("%d",&ch2);
						}
					}while(ch2==1);
					fclose(fp);
					system(cname);
				}
				else
				{
					if(i==20)
					{
						printf("\nMaximum line limit reached...");
					}
					else
					{
						printf("\nYou can add %d lines more with 10 characters in each line",20-i);
						do
						{
							printf("\nEnter the line:\n");
							getchar();
							gets(buffer);

							len=strlen(buffer);
							if(len>10)
							{
								buffer[10]='\0';
							}
							fprintf(fp,"%s\n",buffer);
							i++;
							if(i==20)
							{
								printf("\nLimit reached..");
							}
							else
							{
								printf("\nDo you want to enter more lines...(Yes:1 No:0):");
								scanf("%d",&ch2);
							}
						}while(ch2==1);
						fclose(fp);
						system(cname);
					}
				}
			break;
		case 2:
				fp=fopen(argv[1],"r");
				if(fp==NULL)
				{
					printf("\nFile doesnot exist..");
				}
				else
				{
					printf("\nEnter the line number to be deleted..");
					scanf("%d",&lno);

					i=0;
					while(fgets(buffer,11,fp))
					{
						file_ptr[i]=(char*)malloc(sizeof(char)*12);
						strcpy(file_ptr[i],buffer);
						i++;
					}

					fclose(fp);

					fp=fopen(argv[1],"w");
					if(lno<=i)
					{
						file_ptr[lno-1]=NULL;
						for(j=0;j<i;j++)
						{
							if(file_ptr[j]!=NULL)
							{
								fprintf(fp,"%s",file_ptr[j]);
							}
						}
						printf("\nLine deleted...");
						fclose(fp);
						system(cname);
					}
					else
					{
						printf("\nLine does not exist...");
					}
				}

			break;
		case 3: fp=fopen(argv[1],"r");
				if(fp==NULL)
				{
					printf("\nFile doesnot exist..");

				}
				else
				{
					printf("\nContents of the file are:\n");
					while(fgets(buffer,11,fp))
					{
						printf("%s",buffer);
					}
					fclose(fp);
				}
			break;
		case 4:
				printf("\nThank you.. Visit again..\n");
				return 0;
		default:
				printf("\nWrong choice entered....Please try again..\n");
			break;
		}

		printf("\nDo you want to continue... (Yes:1 No:0)");
		printf("\nEnter your choice..");
		scanf("%d",&ch);

	}while(ch==1);
	return 0;
}
