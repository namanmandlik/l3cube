/*
 ============================================================================
 Name        : Simple_Version_Control.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<fcntl.h>
#include<unistd.h>

#define MAX 200
#define true 1
#define false 0

/*int CompareFiles(char* originalFile, char* currFile)
{
	char buffer_Original[MAX]="\0",buffer_Current[MAX]="\0";

	system("pwd");
	FILE *fd_Original  = fopen(originalFile, "r");
	FILE *fd_Current	= fopen(currFile, "r");

	if (fd_Original == NULL || fd_Current == NULL)
	{
		printf("fndsnfkdsfksjd");
		return false;
	}

	if(ftell(fd_Original)!=ftell(fd_Current))
		return false;

	while(true)
	{
		strcpy(buffer_Original,"\0");
		fgets(buffer_Original,MAX,fd_Original);

		if(strcmp(buffer_Original,"\0")==0)
		{
			break;
		}

		fgets(buffer_Current,MAX,fd_Current);

		if(strcmp(buffer_Original,buffer_Current)!=0)
			return false;

	}

	return true;
}
*/
int CompareFiles(char* originalFile, char* currFile)
{
	struct stat statOriginal, statCurr;
	stat(originalFile, &statOriginal);
	stat(currFile, &statCurr);

	if ((int) statOriginal.st_size != (int) statCurr.st_size)
		return false;

	int fd_Original  = open(originalFile, O_RDONLY);
	int fd_Current	= open(currFile, O_RDONLY);

	if (fd_Original == -1 || fd_Current == -1)
	{
		printf("\nnotopen\n");
		return false;
	}

	int length=1024, bytesRead;
	char *bufferOriginal  = (char*) malloc(length * sizeof(char));
	char *bufferCurr      = (char*) malloc(length * sizeof(char));


	while(true)
	{
		bytesRead = read(fd_Original, bufferOriginal, length);

		if (bytesRead <= 0)
			break;

		bytesRead = read(fd_Current, bufferCurr, bytesRead);

		if (strcmp(bufferOriginal, bufferCurr))
			return false;
	}

	return true;
}
int main(int argc, char * argv[])
{
	int temp,size,count;
	char logname[MAX],newfilename[MAX],buffer[MAX],temp_buf[4],delim[]="\n";
	FILE *fp,*fpw,*fpr;

	if(argc<2 && argc>3)
	{
		printf("\nError1");
		return 0;
	}

	if(argc==2)
	{
		strcpy(logname,argv[1]);
		strcat(logname,"_log.txt");
		fp=fopen(logname,"a+");

		if(fp==NULL)
		{
			printf("\nError");
			return 0;
		}

		fseek(fp, 0, SEEK_END);

		size=ftell(fp);

		fseek(fp,0,SEEK_SET);

		if(size==0)
		{
			count=0;
			fprintf(fp,"%d\n",count);

			strcpy(newfilename,argv[1]);
			strcat(newfilename,"_v");
			sprintf(temp_buf,"%d",count);
			strcat(newfilename,temp_buf);
			strcat(newfilename,".txt");

			fpw=fopen(newfilename,"w");
			fpr=fopen(argv[1],"r");


			while(fgets(buffer,MAX,fpr)!=NULL)
			{
				fprintf(fpw,"%s",buffer);
			}
		}
		else
		{

			while(fgets(buffer,MAX,fp));

			strtok(buffer,delim);

			strcpy(newfilename,argv[1]);
			strcat(newfilename,"_v");
			strcat(newfilename,buffer);
			strcat(newfilename,".txt");

			count=atoi(buffer);

			if(CompareFiles(argv[1],newfilename)==0)
			{
				count++;
				strcpy(newfilename,argv[1]);
				strcat(newfilename,"_v");
				sprintf(temp_buf,"%d",count);
				strcat(newfilename,temp_buf);
				strcat(newfilename,".txt");

				fprintf(fp,"%d\n",count);

				fpw=fopen(newfilename,"w");

				fpr=fopen(argv[1],"r");


				while(fgets(buffer,MAX,fpr)!=NULL)
				{
					fprintf(fpw,"%s",buffer);
				}

			}
		}
	}
	else
	{
		strcpy(logname,argv[1]);
		strcat(logname,"_log.txt");
		fp=fopen(logname,"a+");

		strcpy(newfilename,argv[1]);
		strcat(newfilename,"_v");
		strcat(newfilename,argv[2]);
		strcat(newfilename,".txt");

		while(fgets(buffer,MAX,fp));

		if(atoi(argv[2])>atoi(buffer))
		{
			printf("\nVersion not available...\n");
			return 0;
		}

		fpr=fopen(newfilename,"r");

		if(fpr==NULL)
		{
			perror("Error in opening file");
			return 0;
		}
		strtok(buffer,delim);

		printf("\nContents of the %s version of file are:\n",argv[2]);
		while(fgets(buffer,MAX,fpr))
		{
			printf("%s",buffer);
		}
		printf("\n");

	}
	return EXIT_SUCCESS;
}



